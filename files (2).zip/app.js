// Modern Audio Player - app.js
// Minimal dependency (vanilla JS). Designed to be easy to follow and extend.

(() => {
  // ---- Config / Sample playlist ----
  const playlist = [
    {
      title: "SoundHelix Song 1",
      artist: "SoundHelix",
      album: "Sample",
      src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
      artwork: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder"
    },
    {
      title: "SoundHelix Song 2",
      artist: "SoundHelix",
      album: "Sample",
      src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
      artwork: "https://images.unsplash.com/photo-1507878866276-a947ef722fee?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder"
    },
    {
      title: "SoundHelix Song 3",
      artist: "SoundHelix",
      album: "Sample",
      src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
      artwork: "https://images.unsplash.com/photo-1506784983877-45594efa4cbe?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&s=placeholder"
    }
  ];

  // ---- DOM refs ----
  const audio = document.getElementById('audio');
  const playPauseBtn = document.getElementById('playPauseBtn');
  const playIcon = document.getElementById('playIcon');
  const pauseIcon = document.getElementById('pauseIcon');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const shuffleBtn = document.getElementById('shuffleBtn');
  const repeatBtn = document.getElementById('repeatBtn');
  const muteBtn = document.getElementById('muteBtn');
  const volumeSlider = document.getElementById('volumeSlider');
  const progressPlayed = document.getElementById('progressPlayed');
  const progressBuffered = document.getElementById('progressBuffered');
  const progressWrap = document.getElementById('progressWrap');
  const currentTimeEl = document.getElementById('currentTime');
  const totalTimeEl = document.getElementById('totalTime');
  const titleEl = document.getElementById('title');
  const artistEl = document.getElementById('artist');
  const albumEl = document.getElementById('album');
  const artworkEl = document.getElementById('artwork');
  const playlistList = document.getElementById('playlistList');
  const waveformCanvas = document.getElementById('waveformCanvas');
  const visualToggle = document.getElementById('visualToggle');

  // ---- State ----
  let currentIndex = 0;
  let isPlaying = false;
  let isShuffle = false;
  // repeatMode: 'none' | 'one' | 'all'
  let repeatMode = 'none';
  let audioCtx = null;
  let analyser = null;
  let sourceNode = null;
  let rafId = null;
  let bufferLength = 0;
  let dataArray = null;

  // Build playlist DOM
  function buildPlaylist() {
    playlistList.innerHTML = '';
    playlist.forEach((t, i) => {
      const li = document.createElement('li');
      li.className = 'playlist-item';
      li.dataset.index = i;
      li.tabIndex = 0;
      li.innerHTML = `
        <div class="item-meta" style="flex:1">
          <p class="item-title">${escapeHtml(t.title)}</p>
          <p class="item-sub">${escapeHtml(t.artist)} • ${escapeHtml(t.album)}</p>
        </div>
      `;
      li.addEventListener('click', () => {
        loadTrack(i, true);
      });
      li.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); loadTrack(i, true); }
      });
      playlistList.appendChild(li);
    });
    highlightActive();
  }

  // Escape helper
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  function highlightActive() {
    const items = playlistList.querySelectorAll('.playlist-item');
    items.forEach(it => it.classList.remove('active'));
    const cur = playlistList.querySelector(`[data-index="${currentIndex}"]`);
    if (cur) cur.classList.add('active');
  }

  // Load a track by index
  function loadTrack(index, autoplay = false) {
    if (index < 0 || index >= playlist.length) return;
    currentIndex = index;
    const t = playlist[index];

    // Update UI
    titleEl.textContent = t.title;
    artistEl.textContent = t.artist;
    albumEl.textContent = t.album || '';
    artworkEl.src = t.artwork || artworkEl.src;
    highlightActive();

    // Swap audio
    audio.src = t.src;
    audio.crossOrigin = "anonymous";
    audio.load();

    // Play if requested
    if (autoplay) {
      playAudio();
    } else {
      updatePlayIcon(false);
    }
  }

  // Play / Pause control
  async function playAudio() {
    try {
      // Some browsers require AudioContext resume on user gesture
      if (!audioCtx) initAudioContext();
      if (audioCtx && audioCtx.state === 'suspended') await audioCtx.resume();
      await audio.play();
      isPlaying = true;
      updatePlayIcon(true);
      startVisualizer();
    } catch (err) {
      console.warn('Playback failed', err);
    }
  }

  function pauseAudio() {
    audio.pause();
    isPlaying = false;
    updatePlayIcon(false);
    stopVisualizer();
  }

  function updatePlayIcon(playing) {
    playPauseBtn.setAttribute('aria-pressed', playing ? 'true' : 'false');
    playIcon.hidden = playing;
    pauseIcon.hidden = !playing;
  }

  // Next / Prev
  function nextTrack() {
    if (isShuffle) {
      // pick a random different track
      if (playlist.length > 1) {
        let next;
        do { next = Math.floor(Math.random() * playlist.length); } while (next === currentIndex);
        loadTrack(next, true);
      }
    } else {
      let nextIndex = currentIndex + 1;
      if (nextIndex >= playlist.length) {
        if (repeatMode === 'all') nextIndex = 0;
        else { // none -> stop
          pauseAudio();
          return;
        }
      }
      loadTrack(nextIndex, true);
    }
  }

  function prevTrack() {
    if (audio.currentTime > 3) {
      audio.currentTime = 0;
    } else {
      let prevIndex = currentIndex - 1;
      if (prevIndex < 0) {
        if (repeatMode === 'all') prevIndex = playlist.length - 1;
        else { audio.currentTime = 0; return; }
      }
      loadTrack(prevIndex, true);
    }
  }

  // Seek handling
  function updateProgressUI() {
    if (!audio.duration || isNaN(audio.duration)) {
      currentTimeEl.textContent = '0:00';
      totalTimeEl.textContent = '0:00';
      progressPlayed.style.width = '0%';
      progressBuffered.style.width = '0%';
      return;
    }
    const cur = audio.currentTime;
    const dur = audio.duration;

    currentTimeEl.textContent = formatTime(cur);
    totalTimeEl.textContent = formatTime(dur);

    const pct = (cur / dur) * 100;
    progressPlayed.style.width = pct + '%';

    // buffered — show the last buffered range end percent
    if (audio.buffered && audio.buffered.length) {
      const bufferedEnd = audio.buffered.end(audio.buffered.length - 1);
      const bufferPct = (bufferedEnd / dur) * 100;
      progressBuffered.style.width = bufferPct + '%';
    } else {
      progressBuffered.style.width = '0%';
    }

    // update ARIA
    const sliderValue = Math.round(pct);
    progressWrap.setAttribute('aria-valuenow', sliderValue);
  }

  // Seek on click / drag
  function seekFromEvent(e) {
    const rect = progressWrap.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
    const pct = Math.min(1, Math.max(0, x / rect.width));
    if (audio.duration) audio.currentTime = pct * audio.duration;
  }

  // Volume / mute
  function setVolume(v) {
    audio.volume = v;
    volumeSlider.value = v;
    muteBtn.textContent = v <= 0 ? '🔇' : '🔈';
  }

  function toggleMute() {
    if (audio.muted) {
      audio.muted = false;
      muteBtn.textContent = '🔈';
    } else {
      audio.muted = true;
      muteBtn.textContent = '🔇';
    }
  }

  // Shuffle / Repeat toggles
  function toggleShuffle() {
    isShuffle = !isShuffle;
    shuffleBtn.setAttribute('aria-pressed', isShuffle ? 'true' : 'false');
    shuffleBtn.style.color = isShuffle ? getComputedStyle(document.documentElement).getPropertyValue('--accent') : '';
  }

  function cycleRepeat() {
    if (repeatMode === 'none') repeatMode = 'all';
    else if (repeatMode === 'all') repeatMode = 'one';
    else repeatMode = 'none';
    updateRepeatUI();
  }

  function updateRepeatUI() {
    repeatBtn.setAttribute('aria-pressed', repeatMode !== 'none' ? 'true' : 'false');
    repeatBtn.title = `Repeat (${repeatMode})`;
    repeatBtn.style.color = repeatMode === 'none' ? '' : getComputedStyle(document.documentElement).getPropertyValue('--accent');
  }

  // Format seconds -> M:SS
  function formatTime(sec) {
    if (!sec || isNaN(sec) || !isFinite(sec)) return '0:00';
    const s = Math.floor(sec % 60).toString().padStart(2, '0');
    const m = Math.floor(sec / 60);
    return `${m}:${s}`;
  }

  // ---- Visualizer (waveform) ----
  function initAudioContext() {
    try {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 2048;
      bufferLength = analyser.fftSize;
      dataArray = new Uint8Array(bufferLength);

      if (sourceNode) sourceNode.disconnect();
      sourceNode = audioCtx.createMediaElementSource(audio);
      sourceNode.connect(analyser);
      analyser.connect(audioCtx.destination);
    } catch (err) {
      console.warn('Web Audio API not supported', err);
    }
  }

  function startVisualizer() {
    if (!visualToggle.checked) return;
    if (!audioCtx) initAudioContext();
    if (!analyser) return;

    const canvas = waveformCanvas;
    const ctx = canvas.getContext('2d');
    function resize() {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = canvas.clientWidth * dpr;
      canvas.height = canvas.clientHeight * dpr;
      ctx.scale(dpr, dpr);
    }
    resize();
    window.addEventListener('resize', resize);

    function draw() {
      analyser.getByteTimeDomainData(dataArray);
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      ctx.clearRect(0, 0, w, h);

      // background subtle fill
      ctx.fillStyle = 'rgba(0,0,0,0)';
      ctx.fillRect(0, 0, w, h);

      ctx.lineWidth = 2;
      const grad = ctx.createLinearGradient(0, 0, w, 0);
      grad.addColorStop(0, '#7c5cff');
      grad.addColorStop(1, '#5fb7ff');
      ctx.strokeStyle = grad;
      ctx.beginPath();

      const sliceWidth = w / bufferLength;
      let x = 0;
      for (let i = 0; i < bufferLength; i++) {
        const v = dataArray[i] / 128.0;
        const y = (v * h) / 2;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
        x += sliceWidth;
      }
      ctx.stroke();

      // subtle glow
      ctx.globalCompositeOperation = 'lighter';
      ctx.strokeStyle = 'rgba(95,183,255,0.06)';
      ctx.lineWidth = 8;
      ctx.beginPath();
      x = 0;
      for (let i = 0; i < bufferLength; i++) {
        const v = dataArray[i] / 128.0;
        const y = (v * h) / 2;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
        x += sliceWidth;
      }
      ctx.stroke();
      ctx.globalCompositeOperation = 'source-over';

      rafId = requestAnimationFrame(draw);
    }

    if (!rafId) draw();
  }

  function stopVisualizer() {
    if (rafId) {
      cancelAnimationFrame(rafId);
      rafId = null;
    }
    // clear canvas
    const ctx = waveformCanvas.getContext('2d');
    ctx.clearRect(0, 0, waveformCanvas.clientWidth, waveformCanvas.clientHeight);
  }

  // ---- Events ----
  playPauseBtn.addEventListener('click', () => {
    if (isPlaying) pauseAudio(); else playAudio();
  });

  prevBtn.addEventListener('click', prevTrack);
  nextBtn.addEventListener('click', nextTrack);
  shuffleBtn.addEventListener('click', toggleShuffle);
  repeatBtn.addEventListener('click', cycleRepeat);

  // progress interactions
  let seeking = false;
  progressWrap.addEventListener('mousedown', (e) => { seeking = true; seekFromEvent(e); });
  window.addEventListener('mousemove', (e) => { if (seeking) seekFromEvent(e); });
  window.addEventListener('mouseup', () => { seeking = false; });

  // touch
  progressWrap.addEventListener('touchstart', (e) => { seeking = true; seekFromEvent(e); });
  window.addEventListener('touchmove', (e) => { if (seeking) seekFromEvent(e); }, {passive:true});
  window.addEventListener('touchend', () => { seeking = false; });

  // keyboard seeking on progress (left/right)
  progressWrap.addEventListener('keydown', (e) => {
    if (!audio.duration) return;
    if (e.key === 'ArrowLeft') { audio.currentTime = Math.max(0, audio.currentTime - 5); }
    if (e.key === 'ArrowRight') { audio.currentTime = Math.min(audio.duration, audio.currentTime + 5); }
  });

  // volume
  volumeSlider.addEventListener('input', (e) => setVolume(parseFloat(e.target.value)));
  muteBtn.addEventListener('click', toggleMute);

  // audio timeupdate
  audio.addEventListener('timeupdate', updateProgressUI);
  audio.addEventListener('durationchange', updateProgressUI);
  audio.addEventListener('progress', updateProgressUI);

  // ended -> next / repeat logic
  audio.addEventListener('ended', () => {
    if (repeatMode === 'one') {
      audio.currentTime = 0;
      playAudio();
      return;
    }
    // else next or stop
    if (isShuffle) nextTrack();
    else {
      if (currentIndex < playlist.length - 1) nextTrack();
      else {
        if (repeatMode === 'all') loadTrack(0, true);
        else { pauseAudio(); audio.currentTime = 0; }
      }
    }
  });

  // audio metadata -> update duration & track meta if available
  audio.addEventListener('loadedmetadata', () => {
    updateProgressUI();
  });

  // Visual toggle
  visualToggle.addEventListener('change', () => {
    if (visualToggle.checked) startVisualizer();
    else stopVisualizer();
  });

  // keyboard shortcuts
  window.addEventListener('keydown', (e) => {
    if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
    if (e.code === 'Space') { e.preventDefault(); if (isPlaying) pauseAudio(); else playAudio(); }
    if (e.key === 'ArrowRight') { nextTrack(); }
    if (e.key === 'ArrowLeft') { prevTrack(); }
    if (e.key === 'ArrowUp') { setVolume(Math.min(1, audio.volume + 0.05)); }
    if (e.key === 'ArrowDown') { setVolume(Math.max(0, audio.volume - 0.05)); }
  });

  // Small utilities
  function shuffleArray(arr) {
    // returns new array copy
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  // Expose some debugging helpers on window
  window.__player = {
    playlist,
    loadTrack: (i, auto) => loadTrack(i, !!auto),
    play: playAudio,
    pause: pauseAudio,
    next: nextTrack,
    prev: prevTrack
  };

  // Initialize UI
  function init() {
    buildPlaylist();
    updateRepeatUI();
    setVolume(parseFloat(volumeSlider.value || 0.8));
    // load first track but don't autoplay
    loadTrack(0, false);

    // canvas sizing: set CSS width/height to match artwork
    function syncCanvasSize(){
      // make the canvas sized to the artwork container
      const wrap = document.querySelector('.artwork-wrap');
      waveformCanvas.style.width = wrap.clientWidth + "px";
      waveformCanvas.style.height = wrap.clientHeight + "px";
    }
    syncCanvasSize();
    window.addEventListener('resize', syncCanvasSize);
  }

  // init on DOM ready
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})();